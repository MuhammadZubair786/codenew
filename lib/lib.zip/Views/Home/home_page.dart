// Flutter imports:
// ignore_for_file: missing_return

import 'package:flutter/material.dart';

// Package imports:

import 'package:get/get.dart';
import 'package:lms_flutter_app/Controller/myCourse_controller.dart';
import 'package:lms_flutter_app/Views/MyCourseClassQuiz/MyCourses/my_course_details_view.dart';
import 'package:lms_flutter_app/Views/MyCourseClassQuiz/MyQuiz/my_quiz_details_view.dart';
import 'package:lms_flutter_app/utils/DefaultLoadingWidget.dart';
import 'package:lms_flutter_app/utils/widgets/LoadingSkeletonItemWidget.dart';
import 'package:lms_flutter_app/utils/widgets/SingleCardItemWidget.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:loading_skeleton/loading_skeleton.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:scaled_list/scaled_list.dart';

// Project imports:
import 'package:lms_flutter_app/Config/app_config.dart';
import 'package:lms_flutter_app/Controller/class_controller.dart';
import 'package:lms_flutter_app/Controller/home_controller.dart';
import 'package:lms_flutter_app/Controller/quiz_controller.dart';
import 'package:lms_flutter_app/Views/Home/Class/all_class_view.dart';
import 'package:lms_flutter_app/Views/Home/Class/class_details_page.dart';
import 'package:lms_flutter_app/Views/Home/Course/all_course_view.dart';
import 'package:lms_flutter_app/Views/Home/Course/course_category_page.dart';
import 'package:lms_flutter_app/Views/Home/Course/course_details_page.dart';
import 'package:lms_flutter_app/Views/Home/Quiz/AllQuizzesView.dart';
import 'package:lms_flutter_app/Views/Home/Quiz/quiz_details_page_view.dart';
import 'package:lms_flutter_app/utils/CustomText.dart';
import 'package:lms_flutter_app/utils/widgets/AppBarWidget.dart';

class HomePage extends GetView<HomeController> {
  Color selectColor(int position) {
    Color c;
    if (position % 4 == 0) c = Color(0xff569AFF);
    if (position % 4 == 1) c = Color(0xff6D55FF);
    if (position % 4 == 2) c = Color(0xffD764FF);
    if (position % 4 == 3) c = Color(0xffFF9800);
    return c;
  }

  final List<Color> kMixedColors = [
    Color(0xff71A5D7),
    Color(0xff72CCD4),
    Color(0xffFBAB57),
    Color(0xffF8B993),
    Color(0xff962D17),
    Color(0xffc657fb),
    // Color(0xfffb8457),
  ];

  final Data = [
    0,1,2,3,4,5
  ];

  final List<String> imgList = [
    "https://aca.teratarget.com/le/public/uploads/instructors/05a975d5ad7ebfdb160a1cbb08988df4.jpg",
    "https://aca.teratarget.com/le/public/uploads/instructors/15c37abbbae455a78be4bb549865258f.jpg",
    "https://aca.teratarget.com/le/public/uploads/instructors/8434e365a892f2b902e94f5a2c24752a.jpg",
    "https://aca.teratarget.com/le/public/uploads/instructors/1d6b4ef7255bc5d54ddcacfb5a01baad.jpg",
   
    "https://aca.teratarget.com/le/public/uploads/instructors/e58361ad31ca116c86e5da4d830663d9.jpg",
     "https://aca.teratarget.com/le/public/uploads/instructors/1d6b4ef7255bc5d54ddcacfb5a01baad.jpg",
  ];

  final Category = [
    "فێربوونی زمان",
    "خوێندنی ئنگلیزی",
    "خوێندنی کوردی",
    "خوێندنی کوردی",
    "خوێندنی کوردی",
    "خوێندنی ئنگلیزی"
  ];

  final title = [
    "ماتماتیک پۆلی ١",
    "زمانی عەرەبی",
    "ماتماتیک پۆلی ١",
    "زمانی عەرەبی",
    "ماتماتیک پۆلی ١",
    "ماتماتیک پۆلی ١",
    "بایلۆجی پۆلی"
  ];

  Future<void> refresh() async {
    controller.onInit();
   await controller.getCourseDetails();
  }

  @override
  Widget build(BuildContext context) {
    double width;
    // double percentageWidth;
    double height;
    double percentageHeight;
    width = MediaQuery.of(context).size.width;
    // percentageWidth = width / 100;
    height = MediaQuery.of(context).size.height;
    percentageHeight = height / 100;
    return LoaderOverlay(
      useDefaultLoading: false,
      overlayWidget: defaultLoadingWidget,
      child: SafeArea(
        child: Scaffold(
          appBar: AppBarWidget(
            showSearch: true,
            goToSearch: true,
            showBack: false,
            showFilterBtn: true,
          ),
          body: Container(
            color: Color(0xffF9F9F9),
            child: RefreshIndicator(
              onRefresh: refresh,
              child: ListView(
                physics: BouncingScrollPhysics(),
                children: [
                  // SizedBox(
                  //   height: 15,
                  // ),

                  // Slider Section

                  Container(
                    child: Obx(
                      () {
                        if (controller.isLoading.value) {
                          return Text("");
                        } else {
                          return Container(
                            color: Color(0xffF9F9F9),
                            height: 190,
                            child: CarouselSlider(
                              options: CarouselOptions(
                                autoPlay: true,
                                aspectRatio: 1.0,
                                enlargeCenterPage: true,
                                height: 300,
                                viewportFraction: 1,
                              ),
                              items:
                                  controller.SliderImg.map((item) => Container(
                                        height: 190,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        // padding: EdgeInsets.all(9),
                                        child: Center(
                                            child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(14.0),
                                          child:
                                              // Text(item["image"].toString())
                                              Image.network(
                                            '$rootUrl/${item["image"]}',
                                            width: width * 0.98,
                                          ),
                                        )),
                                      )).toList(),
                            ),
                          );
                        }
                      },
                    ),
                  ),

                  // Container(
                  //   color: Color(0XFFEEECEC),
                  //   height: 190,
                  //   child:

                  //   CarouselSlider(
                  //     options: CarouselOptions(
                  //       autoPlay: true,
                  //   aspectRatio: 1.0,
                  //   enlargeCenterPage: true,
                  //   height: 300,
                  //   viewportFraction: 1,
                  //     ),
                  //     items: controller.SliderImg
                  //         .map((item) => Container(
                  //           decoration: BoxDecoration(
                  //             borderRadius: BorderRadius.circular(10)
                  //           ),
                  //           padding: EdgeInsets.all(4),
                  //               child: Center(
                  //                   child: ClipRRect(
                  //                       borderRadius: BorderRadius.circular(14.0),
                  //                     child:
                  //                     // Text(item["image"].toString())
                  //                     Image.network(
                  //                       '$rootUrl/${item["image"]}'
                  //                       ,
                  //                          width: width*0.98),
                  //                   )),
                  //             ))
                  //         .toList(),
                  //   ),
                  // ),

                  // SizedBox(
                  //   height: 14,
                  // ),

                  /// TOP CATEGORIES
                  Container(
                      margin: EdgeInsets.only(
                        left: 20,
                        bottom: 14.72,
                        right: 20,
                      ),
                      child: Texth1("${stctrl.lang['Top Categories']}")),
                  Container(
                      margin: EdgeInsets.fromLTRB(
                        Get.locale == Locale('ar') ? 0 : 20,
                        0,
                        Get.locale == Locale('ar') ? 20 : 0,
                        0,
                      ),
                      child: Obx(() {
                        if (controller.isLoading.value)
                          return Container(
                            height: 80,
                            child: ListView.separated(
                                scrollDirection: Axis.horizontal,
                                itemCount: 4,
                                separatorBuilder: (context, index) {
                                  return SizedBox(
                                    width: 12,
                                  );
                                },
                                itemBuilder:
                                    (BuildContext context, int indexCat) {
                                  return LoadingSkeleton(
                                    height: 80,
                                    width: 140,
                                    child: Padding(
                                      padding: const EdgeInsets.all(0.0),
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          SizedBox(
                                            height: 8,
                                          ),
                                          LoadingSkeleton(
                                            height: percentageHeight * 1,
                                            width: 140,
                                          ),
                                          SizedBox(
                                            height: 8,
                                          ),
                                          LoadingSkeleton(
                                            height: percentageHeight * 0.5,
                                            width: 60,
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                }),
                          );
                        else {
                          return Container(
                            height: 150,
                            child: ListView.separated(
                                scrollDirection: Axis.horizontal,
                                itemCount: controller.topCatList.length,
                                shrinkWrap: true,
                                physics: BouncingScrollPhysics(),
                                separatorBuilder: (context, index) {
                                  return SizedBox(
                                    width: 15,
                                  );
                                },
                                itemBuilder:
                                    (BuildContext context, int indexCat) {
                                  // print(controller.topCatList[indexCat].image);
                                  return GestureDetector(
                                    child: Container(
                                      decoration: BoxDecoration(
                                        color: Color(0xffF9F9F9),
                                        // borderRadius: BorderRadius.circular(5.0)
                                      ),
                                      height: 250,
                                      width: 100,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                              // padding: EdgeInsets.all(1),
                                              child: ClipRRect(
                                                  borderRadius:
                                                      BorderRadius.only(
                                                    topLeft: Radius.circular(0),
                                                    bottomLeft:
                                                        Radius.circular(0),
                                                    bottomRight:
                                                        Radius.circular(0),
                                                    topRight:
                                                        Radius.circular(0),
                                                  ),
                                                  child: Image.network(
                                                    "$rootUrl/${controller.topCatList[indexCat].image}",
                                                    height: 90,
                                                  ))),
                                          Container(
                                            child: CatTitle(controller
                                                        .topCatList[indexCat]
                                                        .name[
                                                    '${stctrl.code.value}'] ??
                                                "${controller.topCatList[indexCat].name['en']}"),
                                          ),
                                          Container(
                                            child: CatSubTitle(controller
                                                    .topCatList[indexCat]
                                                    .courseCount
                                                    .toString() +
                                                ' ' +
                                                "${stctrl.lang["Courses"]}"),
                                          ),
                                        ],
                                      ),
                                    ),
                                    onTap: () {
                                      Get.to(() => CourseCategoryPage(
                                          controller.topCatList[indexCat].name[
                                                  '${stctrl.code.value}'] ??
                                              "${controller.topCatList[indexCat].name['en']}",
                                          indexCat));
                                    },
                                  );
                                }),
                          );
                        }
                      })),

                  SizedBox(
                    height: 5,
                  ),

                  /// FEATURED COURSES
                  Container(
                      margin: EdgeInsets.only(
                        left: Get.locale == Locale('ar') ? 12 : 20,
                        bottom: 14.72,
                        top: 30,
                        right: Get.locale == Locale('ar') ? 20 : 12,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Texth1("${stctrl.lang["Featured Courses"]}"),
                          Expanded(
                            child: Container(),
                          ),
                          GestureDetector(
                            child: sellAllText(),
                            onTap: () {
                              Get.to(() => AllCourseView());
                            },
                          )
                        ],
                      )),
                  Container(
                    margin: EdgeInsets.fromLTRB(
                        Get.locale == Locale('ar') ? 0 : 15,
                        0,
                        Get.locale == Locale('ar') ? 15 : 0,
                        0),
                    child: Obx(() {
                      if (controller.isLoading.value)
                        return LoadingSkeletonItemWidget();
                      else {
                        return Container(
                          height: 200,
                          child: ListView.separated(
                              scrollDirection: Axis.horizontal,
                              itemCount: controller.popularCourseList.length,
                              separatorBuilder: (context, index) {
                                return SizedBox(
                                  width: 18,
                                );
                              },
                              padding: EdgeInsets.fromLTRB(
                                  Get.locale == Locale('ar') ? 0 : 5,
                                  0,
                                  Get.locale == Locale('ar') ? 5 : 0,
                                  0),
                              physics: BouncingScrollPhysics(),
                              itemBuilder: (BuildContext context, int index) {
                                print('$rootUrl/${controller.popularCourseList[0].thumbnail}');
                                return SingleItemCardWidget(
                                  showPricing: true,
                                  image:
                                      "$rootUrl/${controller.popularCourseList[index].thumbnail}",
                                  title: controller.popularCourseList[index]
                                          .title['${stctrl.code.value}'] ??
                                      "${controller.popularCourseList[index].title['en']}",
                                  subTitle: controller
                                      .popularCourseList[index].user.name,
                                  price:
                                      controller.popularCourseList[index].price,
                                  discountPrice: controller
                                      .popularCourseList[index].discountPrice,
                                  onTap: () async {
                                    context.loaderOverlay.show();
                                    controller.selectedLessonID.value = 0;
                                    controller.courseID.value =
                                        controller.popularCourseList[index].id;
                                    await controller.getCourseDetails();

                                    if (controller.isCourseBought.value) {
                                      final MyCourseController
                                          myCoursesController =
                                          Get.put(MyCourseController());

                                      myCoursesController.courseID.value =
                                          controller
                                              .popularCourseList[index].id;
                                      myCoursesController
                                          .selectedLessonID.value = 0;
                                      myCoursesController
                                          .myCourseDetailsTabController
                                          .controller
                                          .index = 0;

                                      await myCoursesController
                                          .getCourseDetails();
                                      Get.to(() => MyCourseDetailsView());
                                      context.loaderOverlay.hide();
                                    } else {
                                      Get.to(() => CourseDetailsPage());
                                      context.loaderOverlay.hide();
                                    }
                                  },
                                );
                              }),
                        );
                      }
                    }),
                  ),

                  // Instructor Section

                  Container(
                    child: Obx(
                      () {
                        if (controller.isLoading.value) {
                          return Text("");
                        } else {
                          return Container(
                            color: Colors.white,
                            height: 300,
                            child: CarouselSlider(
                                options: CarouselOptions(
                                  autoPlay: true,
                                  aspectRatio: 1.0,
                                  enlargeCenterPage: true,
                                  height: 300,
                                  viewportFraction: 1,
                                ),
                                items: Data
                                    .map((item) => Container(
                                          child: Container(
                                            // width: MediaQuery.of(context).size.width,
                                            // margin: EdgeInsets.all(5.0),
                                            // padding: EdgeInsets.only(top: 30),
                                            child: ClipRRect(
                                                borderRadius: BorderRadius.all(
                                                    Radius.circular(5.0)),
                                                child: Row(
                                                  children: <Widget>[
                                                    Container(
                                                      width:
                                                          MediaQuery.of(context)
                                                                  .size
                                                                  .width *
                                                              0.90,
                                                      margin:
                                                          EdgeInsets.all(10),
                                                      decoration:
                                                          new BoxDecoration(
                                                        boxShadow: [
                                                          new BoxShadow(
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    235,
                                                                    235,
                                                                    235),
                                                            blurRadius: 20.0,
                                                          ),
                                                        ],
                                                      ),
                                                      height: 600,
                                                      child: ClipRRect(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(8.0),
                                                        child: Card(
                                                          elevation: 20,
                                                          child: Row(
                                                            crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                            children: <Widget>[
                                                              Container(
                                                                width: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .width *
                                                                    0.45,
                                                                child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .min,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    Column(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .end,
                                                                      children: [
                                                                        Row(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.spaceBetween,
                                                                          children: [
                                                                            ClipRRect(
                                                                              borderRadius: BorderRadius.circular(8.0),
                                                                              child: Container(
                                                                                //  padding: EdgeInsets.only(left: 15,right: 15),
                                                                                margin: EdgeInsets.only(top: 5, right: 5),

                                                                                child: Container(
                                                                                  color: Colors.black,
                                                                                  padding: EdgeInsets.all(2),
                                                                                  margin: EdgeInsets.all(3),
                                                                                  child: Text(
                                                                                   title[item].toString(),
                                                                                    style: TextStyle(color: Color.fromARGB(255, 251, 250, 253), fontSize: 16),
                                                                                    textAlign: TextAlign.left,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                            Container(
                                                                              margin: EdgeInsets.only(top: 10, right: 10),
                                                                              child: Text("Subtitle", style: TextStyle(color: Colors.black, fontSize: 10), textAlign: TextAlign.right),
                                                                            ),
                                                                          ],

                                                                        ),
                                                                        SizedBox(height: 10,),
                                                                         Container(
                                                                              margin: EdgeInsets.only(top: 10, right: 10),
                                                                              child: Text( Category[item].toString(), style: TextStyle(color: Colors.black, fontSize: 18), textAlign: TextAlign.right),
                                                                            ),
                                                                        SizedBox(
                                                                          height:
                                                                              100,
                                                                        ),
                                                                        Container(
                                                                          padding: EdgeInsets.only(
                                                                            top:10,
                                                                              left: 15,
                                                                              right: 15),
                                                                          //  margin:EdgeInsets.only(left: 15,right: 15),
                                                                          child:
                                                                              Row(
                                                                            mainAxisAlignment:
                                                                                MainAxisAlignment.spaceBetween,
                                                                            children: [
                                                                              ClipRRect(
                                                                                borderRadius: BorderRadius.circular(8.0),
                                                                                child: Container(
                                                                                  color: Colors.pink,
                                                                                  padding: EdgeInsets.all(3),
                                                                                  child: Text(
                                                                                    "\$8000",
                                                                                    style: TextStyle(color: Colors.white, fontSize: 16),
                                                                                    textAlign: TextAlign.left,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                              Row(
                                                                                children: [
                                                                                  Icon(
                                                                                    Icons.star,
                                                                                    color: Colors.yellow,
                                                                                  ),
                                                                                  Text("5.0(5)", style: TextStyle(color: Colors.black, fontSize: 14), textAlign: TextAlign.right),
                                                                                ],
                                                                              ),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              Container(
                                                                height: 400,
                                                                width: MediaQuery.of(
                                                                            context)
                                                                        .size
                                                                        .width *
                                                                    0.42,
                                                                child:
                                                                    ClipRRect(
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              8.0),
                                                                  child: Image.network(
                                                                      imgList[item],
                                                                      fit: BoxFit
                                                                          .fitHeight,
                                                                      width:
                                                                          100),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    )
                                                  ],
                                                )),
                                          ),
                                        ))
                                    .toList()),
                          );
                        }
                      },
                    ),
                  ),

                  //Instructor Section
                  //       ScaledList(
                  //     itemCount: imgList.length,
                  //     itemColor: (index) {
                  //       return kMixedColors[index % kMixedColors.length];
                  //     },
                  //     itemBuilder: (index, selectedIndex) {
                  //       // final category = img[index];
                  //       return Column(
                  //         mainAxisAlignment: MainAxisAlignment.center,
                  //         children: [
                  //           Container(
                  //             height: selectedIndex == index ? 100 : 80,
                  //             child: Image.network(imgList[index])
                  //           ),
                  //           SizedBox(height: 15),
                  // //           Text(
                  // //             category.name,
                  // //             style: TextStyle(
                  // // color: Colors.white,
                  // // fontSize: selectedIndex == index ? 25 : 20),
                  // //           )
                  //         ],
                  //       );
                  //     },
                  //   ),

                  /// FEATURED CLASSES
                  Container(
                    margin: EdgeInsets.only(
                      left: Get.locale == Locale('ar') ? 12 : 20,
                      bottom: 14.72,
                      right: Get.locale == Locale('ar') ? 20 : 12,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Texth1("${stctrl.lang["Featured Class"]}"),
                        Expanded(
                          child: Container(),
                        ),
                        GestureDetector(
                          child: sellAllText(),
                          onTap: () {
                            Get.to(() => AllClassView());
                          },
                        )
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(
                        Get.locale == Locale('ar') ? 0 : 15,
                        0,
                        Get.locale == Locale('ar') ? 15 : 0,
                        0),
                    child: Obx(() {
                      if (controller.isLoading.value)
                        return LoadingSkeletonItemWidget();
                      else {
                        return Container(
                          height: 200,
                          child: ListView.separated(
                              scrollDirection: Axis.horizontal,
                              itemCount: controller.allClassesList.length,
                              separatorBuilder: (context, index) {
                                return SizedBox(
                                  width: 18,
                                );
                              },
                              padding: EdgeInsets.fromLTRB(
                                  Get.locale == Locale('ar') ? 0 : 5,
                                  0,
                                  Get.locale == Locale('ar') ? 5 : 0,
                                  0),
                              physics: BouncingScrollPhysics(),
                              itemBuilder: (BuildContext context, int index) {
                                print(
                                    '$rootUrl/${controller.allClassesList[index].image}');
                                print(
                                    '${controller.allClassesList[index].title['en']}');
                                return SingleItemCardWidget(
                                  showPricing: true,
                                  image:
                                      "$rootUrl/${controller.allClassesList[index].image}",
                                  title: controller.allClassesList[index]
                                          .title['${stctrl.code.value}'] ??
                                      "${controller.allClassesList[index].title['en']}",
                                  subTitle: controller
                                      .allClassesList[index].user.name,
                                  price: controller.allClassesList[index].price,
                                  discountPrice: controller
                                      .allClassesList[index].discountPrice,
                                  onTap: () async {
                                    final ClassController allCourseController =
                                        Get.put(ClassController());
                                    allCourseController.courseID.value =
                                        controller.allClassesList[index].id;
                                    allCourseController.getClassDetails();
                                    Get.to(() => ClassDetailsPage());
                                  },
                                );
                              }),
                        );
                      }
                    }),
                  ),

                  /// FEATURED QUIZZES
                  Container(
                    margin: EdgeInsets.only(
                      left: Get.locale == Locale('ar') ? 12 : 20,
                      bottom: 14.72,
                      right: Get.locale == Locale('ar') ? 20 : 12,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Texth1("${stctrl.lang["Featured Quizzes"]}"),
                        Expanded(
                          child: Container(),
                        ),
                        GestureDetector(
                          child: sellAllText(),
                          onTap: () {
                            Get.to(() => AllQuizView());
                          },
                        )
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(
                        Get.locale == Locale('ar') ? 0 : 15,
                        0,
                        Get.locale == Locale('ar') ? 15 : 0,
                        0),
                    child: Obx(() {
                      if (controller.isLoading.value)
                        return LoadingSkeletonItemWidget();
                      else {
                        return Container(
                          height: 200,
                          child: ListView.separated(
                              scrollDirection: Axis.horizontal,
                              itemCount: controller.allQuizzesList.length,
                              separatorBuilder: (context, index) {
                                return SizedBox(
                                  width: 18,
                                );
                              },
                              padding: EdgeInsets.fromLTRB(
                                  Get.locale == Locale('ar') ? 0 : 5,
                                  0,
                                  Get.locale == Locale('ar') ? 5 : 0,
                                  0),
                              physics: BouncingScrollPhysics(),
                              itemBuilder: (BuildContext context, int index) {
                                return SingleItemCardWidget(
                                  showPricing: true,
                                  image:
                                      "$rootUrl/${controller.allQuizzesList[index].image}",
                                  title: controller.allQuizzesList[index]
                                          .title['${stctrl.code.value}'] ??
                                      "${controller.allQuizzesList[index].title['en']}",
                                  subTitle: controller
                                      .allQuizzesList[index].user.name,
                                  price: controller.allQuizzesList[index].price,
                                  discountPrice: controller
                                      .allQuizzesList[index].discountPrice,
                                  onTap: () async {
                                    context.loaderOverlay.show();
                                    final QuizController allQuizController =
                                        Get.put(QuizController());
                                    allQuizController.courseID.value =
                                        controller.allQuizzesList[index].id;

                                    await allQuizController.getQuizDetails();

                                    if (allQuizController.isQuizBought.value) {
                                      await allQuizController
                                          .getMyQuizDetails();
                                      Get.to(() => MyQuizDetailsPageView());
                                      context.loaderOverlay.hide();
                                    } else {
                                      Get.to(() => QuizDetailsPageView());
                                      context.loaderOverlay.hide();
                                    }
                                  },
                                );
                              }),
                        );
                      }
                    }),
                  ),

                  //**  POPULAR COURSES
                  Container(
                      margin: EdgeInsets.only(
                        left: Get.locale == Locale('ar') ? 12 : 20,
                        bottom: 14.72,
                        top: 27,
                        right: Get.locale == Locale('ar') ? 20 : 12,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Texth1("${stctrl.lang["Popular Courses"]}"),
                          GestureDetector(
                            child: Container(
                              child: sellAllText(),
                            ),
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => AllCourseView(),
                                  ));
                            },
                          )
                        ],
                      )),
                  Container(
                    margin: EdgeInsets.fromLTRB(20, 0, 20, 0),
                    child: Obx(() {
                      if (controller.isLoading.value)
                        return ListView.builder(
                            scrollDirection: Axis.vertical,
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: 4,
                            itemBuilder: (BuildContext context, int index) {
                              return Container(
                                decoration: BoxDecoration(
                                  color: Get.theme.cardColor,
                                  borderRadius: BorderRadius.circular(5.0),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Get.theme.shadowColor,
                                      blurRadius: 10.0,
                                      offset: Offset(2, 3),
                                    ),
                                  ],
                                ),
                                margin: EdgeInsets.fromLTRB(0, 5.8, 0, 5.8),
                                height: 78,
                                width: Get.width,
                                child: Row(
                                  children: [
                                    Container(
                                      child: LoadingSkeleton(
                                        width: 88,
                                        height: 78,
                                      ),
                                    ),
                                    Flexible(
                                      child: Container(
                                        width: 220,
                                        margin: EdgeInsets.only(
                                            left: 16, right: 16),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            LoadingSkeleton(
                                              height: 10,
                                              width: double.maxFinite,
                                            ),
                                            SizedBox(
                                              height: 15,
                                            ),
                                            LoadingSkeleton(
                                              height: 10,
                                              width: double.maxFinite,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            });
                      else {
                        return ListView.builder(
                            scrollDirection: Axis.vertical,
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: controller.popularCourseList.length,
                            itemBuilder: (BuildContext context, int index) {
                              return GestureDetector(
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(20.0),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Get.theme.cardColor,
                                      borderRadius: BorderRadius.circular(5.0),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Get.theme.shadowColor,
                                          blurRadius: 10.0,
                                          offset: Offset(2, 3),
                                        ),
                                      ],
                                    ),
                                    margin: EdgeInsets.fromLTRB(0, 5.8, 0, 5.8),
                                    child: Row(
                                      children: [
                                        ClipRRect(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(5)),
                                          child: Container(
                                            alignment: Alignment.center,
                                            child: ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(14.0),
                                              child: FadeInImage(
                                                image: NetworkImage(
                                                    "$rootUrl/${controller.popularCourseList[index].image}"),
                                                placeholder: AssetImage(
                                                    'images/fcimg.png'),
                                                imageErrorBuilder:
                                                    (BuildContext context,
                                                        Object exception,
                                                        StackTrace stackTrace) {
                                                  return Image.asset(
                                                    'images/fcimg.png',
                                                    fit: BoxFit.cover,
                                                    width: 88,
                                                    height: 78,
                                                  );
                                                },
                                                fit: BoxFit.cover,
                                                width: 88,
                                                height: 78,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Flexible(
                                          child: Container(
                                            width: 220,
                                            margin: EdgeInsets.only(
                                                left: 16, right: 16),
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                PopularPostTitle(controller
                                                            .popularCourseList[
                                                                index]
                                                            .title[
                                                        '${stctrl.code.value}'] ??
                                                    "${controller.popularCourseList[index].title['en']}"),
                                                SizedBox(
                                                  height: 2,
                                                ),
                                                courseTPublisher(controller
                                                    .popularCourseList[index]
                                                    .user
                                                    .name)
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                onTap: () async {
                                  context.loaderOverlay.show();
                                  controller.courseID.value =
                                      controller.popularCourseList[index].id;
                                  await controller.getCourseDetails();

                                  if (controller.isCourseBought.value) {
                                    final MyCourseController
                                        myCoursesController =
                                        Get.put(MyCourseController());

                                    myCoursesController.courseID.value =
                                        controller.popularCourseList[index].id;
                                    myCoursesController.selectedLessonID.value =
                                        0;
                                    myCoursesController
                                        .myCourseDetailsTabController
                                        .controller
                                        .index = 0;

                                    await myCoursesController
                                        .getCourseDetails();
                                    Get.to(() => MyCourseDetailsView());
                                    context.loaderOverlay.hide();
                                  } else {
                                    Get.to(() => CourseDetailsPage());
                                    context.loaderOverlay.hide();
                                  }
                                },
                              );
                            });
                      }
                    }),
                  ),
                  SizedBox(
                    height: 80,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
