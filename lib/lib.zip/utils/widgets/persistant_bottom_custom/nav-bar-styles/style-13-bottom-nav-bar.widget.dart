part of persistent_bottom_nav_bar;

class BottomNavStyle13 extends StatefulWidget {
  final NavBarEssentials navBarEssentials;

  BottomNavStyle13({
    Key key,
    this.navBarEssentials = const NavBarEssentials(items: null),
  });

  @override
  _BottomNavStyle13State createState() => _BottomNavStyle13State();
}

class _BottomNavStyle13State extends State<BottomNavStyle13>
    with TickerProviderStateMixin {
  List<AnimationController> _animationControllerList;
  List<Animation<Offset>> _animationList;

  int _lastSelectedIndex;
  int _selectedIndex;

  @override
  void initState() {
    super.initState();
    _lastSelectedIndex = 0;
    _selectedIndex = 0;
    // ignore: deprecated_member_use
    _animationControllerList = List<AnimationController>();
    // ignore: deprecated_member_use
    _animationList = List<Animation<Offset>>();

    for (int i = 0; i < widget.navBarEssentials.items.length; ++i) {
      _animationControllerList.add(AnimationController(
          duration: widget.navBarEssentials.itemAnimationProperties?.duration ??
              Duration(milliseconds: 400),
          vsync: this));
      _animationList.add(Tween(
              begin: Offset(0, widget.navBarEssentials.navBarHeight / 1.5),
              end: Offset(0, 0.0))
          .chain(CurveTween(
              curve: widget.navBarEssentials.itemAnimationProperties?.curve ??
                  Curves.ease))
          .animate(_animationControllerList[i]));
    }

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _animationControllerList[_selectedIndex].forward();
    });
  }

  Widget _buildItem(PersistentBottomNavBarItem item, bool isSelected,
      double height, int itemIndex) {
    double itemWidth = ((MediaQuery.of(context).size.width -
            ((widget.navBarEssentials.padding?.left ??
                    MediaQuery.of(context).size.width * 0.05) +
                (widget.navBarEssentials.padding?.right ??
                    MediaQuery.of(context).size.width * 0.05))) /
        widget.navBarEssentials.items.length);
    return widget.navBarEssentials.navBarHeight == 0
        ? SizedBox.shrink()
        : AnimatedBuilder(
            animation: _animationList[itemIndex],
            builder: (context, child) => Container(
              width: 150.0,
              height: height,
              child: Container(
                alignment: Alignment.center,
                height: height,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Expanded(
                      child: IconTheme(
                        data: IconThemeData(
                            size: item.iconSize,
                            color: isSelected
                                ? (item.activeColorSecondary == null
                                    ? item.activeColorPrimary
                                    : item.activeColorSecondary)
                                : item.inactiveColorPrimary == null
                                    ? item.activeColorPrimary
                                    : item.inactiveColorPrimary),
                        child: isSelected
                            ? item.icon
                            : item.inactiveIcon ?? item.icon,
                      ),
                    ),
                    item.title == null
                        ? SizedBox.shrink()
                        : Transform.translate(
                            offset: _animationList[itemIndex].value,
                            child: AnimatedContainer(
                              duration: widget.navBarEssentials
                                      .itemAnimationProperties?.duration ??
                                  Duration(milliseconds: 400),
                              height: 5.0,
                              width: itemWidth * 0.8,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(100.0),
                                  color: isSelected
                                      ? (item.activeColorSecondary == null
                                          ? item.activeColorPrimary
                                          : item.activeColorSecondary)
                                      : Colors.transparent),
                            ),
                          ),
                  ],
                ),
              ),
            ),
          );
  }

  @override
  void dispose() {
    for (int i = 0; i < widget.navBarEssentials.items.length; ++i) {
      _animationControllerList[i].dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.navBarEssentials.items.length !=
        _animationControllerList.length) {
      // ignore: deprecated_member_use
      _animationControllerList = List<AnimationController>();
      // ignore: deprecated_member_use
      _animationList = List<Animation<Offset>>();

      for (int i = 0; i < widget.navBarEssentials.items.length; ++i) {
        _animationControllerList.add(AnimationController(
            duration:
                widget.navBarEssentials.itemAnimationProperties?.duration ??
                    Duration(milliseconds: 400),
            vsync: this));
        _animationList.add(Tween(
                begin: Offset(0, widget.navBarEssentials.navBarHeight / 2.0),
                end: Offset(0, 0.0))
            .chain(CurveTween(
                curve: widget.navBarEssentials.itemAnimationProperties?.curve ??
                    Curves.ease))
            .animate(_animationControllerList[i]));
      }
    }
    if (widget.navBarEssentials.selectedIndex != _selectedIndex) {
      _lastSelectedIndex = _selectedIndex;
      _selectedIndex = widget.navBarEssentials.selectedIndex;
      _animationControllerList[_selectedIndex].forward();
      _animationControllerList[_lastSelectedIndex].reverse();
    }
    return Container(
      width: double.infinity,
      height: widget.navBarEssentials.navBarHeight,
      padding: EdgeInsets.only(
          left: widget.navBarEssentials.padding?.left ??
              MediaQuery.of(context).size.width * 0.04,
          right: widget.navBarEssentials.padding?.right ??
              MediaQuery.of(context).size.width * 0.04,
          top: widget.navBarEssentials.padding?.top ??
              widget.navBarEssentials.navBarHeight * 0.15,
          bottom: widget.navBarEssentials.padding?.bottom ??
              widget.navBarEssentials.navBarHeight * 0.12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: widget.navBarEssentials.items.map((item) {
          int index = widget.navBarEssentials.items.indexOf(item);
          return Expanded(
            child: GestureDetector(
              onTap: () {
                if (widget.navBarEssentials.items[index].onPressed != null) {
                  widget.navBarEssentials.items[index].onPressed(
                      widget.navBarEssentials.selectedScreenBuildContext);
                } else {
                  if (index != _selectedIndex) {
                    _lastSelectedIndex = _selectedIndex;
                    _selectedIndex = index;
                    _animationControllerList[_selectedIndex].forward();
                    _animationControllerList[_lastSelectedIndex].reverse();
                  }
                  widget.navBarEssentials.onItemSelected(index);
                }
              },
              child: Container(
                color: Colors.transparent,
                child: _buildItem(
                    item,
                    widget.navBarEssentials.selectedIndex == index,
                    widget.navBarEssentials.navBarHeight,
                    index),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
